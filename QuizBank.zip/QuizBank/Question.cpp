#include "Question.h"

Question::Question()
{
    queStr="";
    answerDef="";
}

Question::~Question()
{

}

void Question::inserQuestion(string que)
{
    queStr = que;
}

void Question::display()
{
    cout<<queStr<<endl;
}

void Question::insertanswer(string _ans)
{
    answerDef = _ans;
}

bool Question::matchOption(string _ans)
{
    if(answerDef == _ans)
        return true;
    return false;
}
string Question::getAnswer()
{
    return answerDef;
}

field Question::getType()
{
    return type;
}

QuestionBank::QuestionBank()
{

}
QuestionBank::~QuestionBank()
{

}

void QuestionBank::displayAllQuestion()
{
    map<field,vector<Question*>>::iterator mpItr;// qList;
    for(mpItr = qList.begin();mpItr != qList.end(); ++mpItr)
    {
        (mpItr->second).display();
    }
}
int QuestionBank::getQuestionNum()
{
    return qList.size();
}
Question* QuestionBank::getQuestion(int idx)
{
    return qList[idx];
}
void QuestionBank::inserQuestion(Question* _obj)
{
    field temp = _obj->getType();
    qList[temp].push_back(_obj);
    ansList[temp].push_back(_obj->getAnswer());

}

vector<string> QuestionBank::getAnswerList(field _type)
{

    return ansList[_type];
}
