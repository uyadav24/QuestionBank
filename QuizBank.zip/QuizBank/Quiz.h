#ifndef QUIZ_H_INCLUDED
#define QUIZ_H_INCLUDED
#include "Question.h"
using namespace std;
class Quiz
{
public:
    string title;
    QuestionBank* Qb;
    set<int> visit;
    vector<Question*> queList;
    Quiz(string _title);
    ~Quiz();
    void insertQB(QuestionBank* _qbObj);
    void createQuiz();
    void showTitle();

};

class QuizBank
{
public:
    QuizBank();
    ~QuizBank();
     vector<Quiz*> quizList;
    void listAllQuiz();
};

#endif // QUIZ_H_INCLUDED
