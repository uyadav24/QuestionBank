#include <iostream>
#include "Question.h"
#include "Quiz.h"

using namespace std;

int main()
{
    QuestionBank* qbank = new QuestionBank();
    Question* quObj = NULL;
    Quiz* qz = new Quiz("sport");
   cout<<" Enter the choice ";
   int choice;
   cout<<" 1. create question,\n2. capture Answer. \n 3. create a quiz.\n 4. List all Quiz.\n 5. List user Answer\n 6. Exit";
   cin>>choice;
   switch(choice)
   {
   case 1:
     quObj = new Question();
     qbank->inserQuestion(quObj);
     break;
   default:
    break;
   }
    return 0;
}
