#ifndef ANSWER_H_INCLUDED
#define ANSWER_H_INCLUDED
#include "Question.h"

class answer
{
public:
    answer();
    ~answer();
    vector<string> getOptions(QuestionBank* _qb,Question* _qu);
};


#endif // ANSWER_H_INCLUDED
