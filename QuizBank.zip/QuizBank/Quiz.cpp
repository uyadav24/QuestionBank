#include "Quiz.h"

Quiz::Quiz(string _title)
{
    title=_title;
}

Quiz::~Quiz()
{

}
void Quiz::insertQB(QuestionBank* _obj)
{
    Qb = _obj;
}
void Quiz::showTitle()
{
    cout<<title;
}
void Quiz::createQuiz()
{
    int entry;
    cout<<" How many question want in this quiz ";
    cin>>entry;
    int len= Qb->getQuestionNum();
    int count=0;
    for(auto i =1;i<=entry;++i)
    {
        count =0;
    while(true)
    {
    int num = rand()%len;
    if(visit.find(num) == visit.end())
    {
        visit.insert(num);
        Question* queObj = Qb->getQuestion(num);
        queList.push_back(queObj);
        queObj->display();
        break;
    }
    ++count;
    if(count == len)
        break;
    }
    }
}

QuizBank::QuizBank()
{

}

QuizBank::~QuizBank()
{

}

void QuizBank::listAllQuiz()
{
    for(auto itr : quizList)
    {
        (*itr)->showTitle();
    }
}
