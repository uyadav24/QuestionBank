#ifndef QUESTION_H_INCLUDED
#define QUESTION_H_INCLUDED
#include <bits/stdc++.h>

using namespace std;
enum field
{
    SPORT,
    POLITY,
    GK,
};
class Question
{
public:
    string queStr;
    string answerDef;
    field type;
    Question();
    ~Question();
    void inserQuestion(string _str);
    void insertanswer(string _ans);
    void display();
    bool matchOption(string _ans);
    field getType();
    string getAnswer();
};

class QuestionBank
{
public:
    //set<>
    map<field,vector<Question*>> qList;
    map<field,vector<string>> ansList;
    QuestionBank();
    ~QuestionBank();
    void displayAllQuestion();
    void inserQuestion(Question* queObj);
    Question* getQuestion(int idx);
    vector<string> getAnswerList(field _type);
};

#endif // QUESTION_H_INCLUDED
