#include "answer.h"

answer::answer()
{

}

answer::~answer()
{

}


vector<string> answer::getOptions(QuestionBank* _qb,Question* qu)
{
     vector<string> optionList;
     vector<string> completeList = _qb->getAnswerList(qu->getType());
     optionList.push_back(qu->getAnswer());
    int len = completeList.size();
    if(len <4 )
    {
        cout<<" not sufficient answers";
    }
    else
    {
        for(auto i =0;i<4;++i)
        {
        int idx = rand()%len;
        optionList.push_back(completeList[idx]);
        }
    }
    return optionList;
}
